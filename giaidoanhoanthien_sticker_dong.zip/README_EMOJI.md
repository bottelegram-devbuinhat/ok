# Koka Game • Sticker Động Telegram

Bộ gồm 27 sticker động định dạng `.tgs` (Lottie vector), theo chủ đề xúc xắc, tiền thưởng, lì xì, Giftcode, thông báo và quản trị. Source sticker và manifest nằm trong `sticker_pack/`.

## Cách sử dụng

1. Giữ nguyên thư mục `sticker_pack/` khi cập nhật/deploy bot.
2. Cài thư viện: `pip install -r requirements.txt` (Python 3.11/3.12 được khuyến nghị).
3. Khởi động bot. Bot có thể gửi trực tiếp file TGS trong các tình huống đã tích hợp: `/start`, ALL IN thành công, nhận lì xì, kết quả thắng/thua và kết quả duyệt rút.
4. Admin có thể gửi `/taosticker` trong chat riêng với bot để tạo bộ sticker thường trên Telegram và lấy link `t.me/addstickers/...` để chia sẻ.
5. Bot lưu `file_id` Telegram trong `sticker_pack/file_ids.json`; giữ file này giữa các lần deploy để tránh phải upload lại.

## Không cần Telegram Premium

Đây là **sticker động thông thường**, không phải Custom Emoji. Bot gửi `.tgs` bằng `sendSticker` và tạo sticker set với `sticker_type=regular`; các sticker được gắn emoji tương ứng. Không thể đặt trực tiếp TGS bên trong câu chữ hoặc nhúng animation chạy trong nút bấm. Vì vậy bot gửi sticker như một tin nhắn riêng và vẫn giữ emoji Unicode trong nội dung/nút.

## Danh sách

🎲 💰 🎁 🧧 👑 ✨ 🔥 ✅ ⚠️ 📢 🎟️ 💳 🛡️ 👥 📊 📜 📖 🔗 🏆 🧾 💸 🔔 🔕 ❌ 🛑 🚫 🔓
