"""Generate small loopable Telegram TGS custom-emoji animations using Lottie vectors."""
from __future__ import annotations
import gzip, json
from pathlib import Path

OUT = Path(__file__).parent / "emoji_pack"
OUT.mkdir(exist_ok=True)


def rgba(hex_color: str):
    h = hex_color.lstrip('#')
    return [int(h[i:i+2], 16) / 255 for i in (0, 2, 4)] + [1]


def kf(values, times=(0, 24, 48, 72, 96, 120, 144, 179)):
    result = []
    for idx, (t, val) in enumerate(zip(times, values)):
        item = {"t": t, "s": val}
        if idx < len(values) - 1:
            item["e"] = values[idx + 1]
            item["o"] = {"x": [0.32], "y": [0.0]}
            item["i"] = {"x": [0.68], "y": [1.0]}
        result.append(item)
    return {"a": 1, "k": result}


def constant(value):
    return {"a": 0, "k": value}


def ellipse(w, h, x=0, y=0):
    return {"ty": "el", "d": 1, "s": constant([w, h]), "p": constant([x, y]), "nm": "Ellipse"}


def rect(w, h, radius=28, x=0, y=0):
    return {"ty": "rc", "d": 1, "s": constant([w, h]), "p": constant([x, y]), "r": constant(radius), "nm": "Rounded rectangle"}


def path(points, closed=True, name="Vector path"):
    verts = [[float(x), float(y)] for x, y in points]
    data = {"c": closed, "v": verts, "i": [[0, 0] for _ in verts], "o": [[0, 0] for _ in verts]}
    return {"ty": "sh", "d": 1, "ks": constant(data), "nm": name}


def fill(hex_color):
    return {"ty": "fl", "c": constant(rgba(hex_color)), "o": constant(100), "r": 1, "bm": 0, "nm": "Fill"}


def stroke(hex_color, width=18):
    return {"ty": "st", "c": constant(rgba(hex_color)), "o": constant(100), "w": constant(width), "lc": 2, "lj": 2, "ml": 4, "bm": 0, "nm": "Stroke"}


def transform(scale=None, rotation=None, position=(256, 256)):
    if scale is None:
        scale = [[100, 100, 100]] * 8
    if rotation is None:
        rotation = [[0]] * 8
    return {
        "o": constant(100), "r": kf(rotation), "p": constant([position[0], position[1], 0]),
        "a": constant([0, 0, 0]), "s": kf(scale), "sk": constant(0), "sa": constant(0)
    }


def layer(name, geometry, color, mode="fill", pos=(0, 0), scale=None, rotation=None, outline=None, outline_w=18):
    shapes = [geometry]
    if mode in ("fill", "both"):
        shapes.append(fill(color))
    if mode in ("stroke", "both"):
        shapes.append(stroke(outline or "#18243A", outline_w))
    return {
        "ddd": 0, "ind": 1, "ty": 4, "nm": name, "sr": 1,
        "ks": transform(scale, rotation, (256 + pos[0], 256 + pos[1])),
        "ao": 0, "shapes": shapes, "ip": 0, "op": 180, "st": 0, "bm": 0
    }


def make_tgs(filename, emoji, title, layers):
    # Give every layer a stable, unique index.
    for index, item in enumerate(layers, 1):
        item["ind"] = index
    composition = {
        "v": "5.7.4", "fr": 60, "ip": 0, "op": 180,
        "w": 512, "h": 512, "nm": f"{title} custom emoji",
        "ddd": 0, "assets": [], "layers": layers,
        "markers": []
    }
    raw = json.dumps(composition, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    compressed = gzip.compress(raw, compresslevel=9, mtime=0)
    if len(compressed) > 64 * 1024:
        raise ValueError(f"{filename} exceeds Telegram's 64KB limit")
    (OUT / filename).write_bytes(compressed)
    # JSON integrity and exact TGS gzip framing check.
    decoded = json.loads(gzip.decompress(compressed).decode("utf-8"))
    assert decoded["w"] == 512 and decoded["h"] == 512 and decoded["fr"] == 60 and decoded["op"] <= 180
    return {"file": filename, "emoji": emoji, "title": title, "bytes": len(compressed)}


pulse = [[94,94,100],[108,108,100],[100,100,100],[96,96,100],[104,104,100],[100,100,100],[98,98,100],[94,94,100]]
soft_pulse = [[98,98,100],[104,104,100],[100,100,100],[98,98,100],[102,102,100],[100,100,100],[98,98,100],[98,98,100]]
wiggle = [[0],[7],[0],[-7],[0],[5],[0], [0]]

specs = []
# Dice: white rounded die, dark pips, soft bounce.
l=[]
l += [layer("Dice body", rect(326,326,58), "#F5F7FC", "both", scale=pulse, outline="#27364B", outline_w=18)]
for x,y in [(-92,-92),(0,0),(92,92),(-92,92),(92,-92)]:
    l.append(layer("Dice pip", ellipse(38,38), "#26364B", pos=(x,y), scale=soft_pulse))
specs.append(make_tgs("dice.tgs","🎲","Xúc xắc",l))

# Coin: gold medal-like coin with inner ring and stylized VND mark.
l=[]
l += [layer("Coin rim", ellipse(360,360), "#D88A12", "both", scale=pulse, outline="#7C4A0A", outline_w=18)]
l += [layer("Coin center", ellipse(292,292), "#FFC94A", "both", outline="#FFF0A8", outline_w=12)]
l += [layer("Coin shine", ellipse(62,34), "#FFF4C5", pos=(-74,-96), rotation=wiggle)]
l += [layer("Coin stem", rect(26,150,13), "#A45E05", pos=(0,0))]
l += [layer("Coin top", rect(92,24,12), "#A45E05", pos=(0,-72))]
l += [layer("Coin bottom", rect(92,24,12), "#A45E05", pos=(0,72))]
specs.append(make_tgs("coin.tgs","💰","Đồng xu",l))

# Gift: red present, golden bands, two loops.
l=[]
l += [layer("Gift box", rect(310,220,26), "#EF476F", pos=(0,48), scale=pulse, outline="#9F2344", outline_w=16)]
l += [layer("Gift lid", rect(360,72,22), "#FF6B83", pos=(0,-92), scale=soft_pulse, outline="#9F2344", outline_w=14)]
l += [layer("Gift ribbon vertical", rect(54,274,12), "#FFD166", pos=(0,40))]
l += [layer("Gift ribbon bow left", path([(-8,-128),(-100,-220),(-160,-194),(-146,-116),(-70,-92)],True), "#FFD166", outline="#B77B17", mode="both", pos=(-44,-30), scale=soft_pulse, outline_w=10)]
l += [layer("Gift ribbon bow right", path([(8,-128),(100,-220),(160,-194),(146,-116),(70,-92)],True), "#FFE08A", outline="#B77B17", mode="both", pos=(44,-30), scale=soft_pulse, outline_w=10)]
l += [layer("Gift knot", ellipse(56,56), "#FFEEAA", pos=(0,-133))]
specs.append(make_tgs("gift.tgs","🎁","Hộp quà",l))

# Red envelope: round red rectangle with gold flap and coin seal.
l=[]
l += [layer("Envelope body", rect(338,270,42), "#E84646", "both", pos=(0,28), scale=pulse, outline="#9E282C", outline_w=18)]
l += [layer("Envelope flap", path([(-168,-75),(0,66),(168,-75),(168,-102),(-168,-102)],True), "#FF6961", "both", pos=(0,-18), outline="#9E282C", outline_w=14)]
l += [layer("Envelope seal", ellipse(88,88), "#FFD166", "both", pos=(0,6), outline="#A6650D", outline_w=12)]
l += [layer("Envelope seal shine", ellipse(24,24), "#FFF0AD", pos=(-16,-10))]
specs.append(make_tgs("red_envelope.tgs","🧧","Lì xì",l))

# Crown: three points and jewels.
l=[]
l += [layer("Crown base", path([(-174,-92),(-130,92),(130,92),(174,-92),(78,-12),(0,-150),(-78,-12)],True), "#FFC83D", "both", scale=pulse, outline="#8A5B0A", outline_w=18)]
l += [layer("Crown band", rect(286,62,18), "#F2A900", pos=(0,74), outline="#8A5B0A", mode="both", outline_w=12)]
for x,col in [(-88,"#54C6EB"),(0,"#F86F9C"),(88,"#70D69A")]:
    l.append(layer("Crown jewel", ellipse(42,42), col, "both", pos=(x,10), scale=soft_pulse, outline="#FFFFFF", outline_w=8))
specs.append(make_tgs("crown.tgs","👑","Vương miện",l))

# Sparkles: asymmetric four-point stars made from paths (not AE star primitives).
star = [(0,-170),(34,-44),(160,0),(34,34),(0,164),(-34,34),(-160,0),(-34,-44)]
l=[]
l += [layer("Main sparkle", path(star,True), "#FFE066", scale=pulse, rotation=wiggle, outline="#D58E18", mode="both", outline_w=12)]
l += [layer("Small sparkle left", path([(0,-56),(12,-12),(56,0),(12,12),(0,56),(-12,12),(-56,0),(-12,-12)],True), "#FFFFFF", pos=(-150,126), scale=soft_pulse)]
l += [layer("Small sparkle right", path([(0,-48),(10,-10),(48,0),(10,10),(0,48),(-10,10),(-48,0),(-10,-10)],True), "#8CE7FF", pos=(142,-126), rotation=[[0],[12],[0],[-12],[0],[8],[0],[0]])]
specs.append(make_tgs("sparkle.tgs","✨","Lấp lánh",l))

# Flame: orange outer flame, yellow inner flame and red tip.
outer = [(-132,160),(-174,68),(-154,-18),(-94,-116),(-72,-190),(-16,-130),(28,-58),(52,-154),(132,-66),(162,30),(140,118),(78,178),(0,204)]
inner = [(-76,146),(-114,72),(-92,6),(-38,-62),(-16,-116),(30,-56),(50,20),(84,-24),(104,50),(82,116),(36,156),(0,168)]
l=[]
l += [layer("Flame outer", path(outer,True), "#FF6B35", "both", scale=pulse, outline="#B83324", outline_w=14)]
l += [layer("Flame inner", path(inner,True), "#FFD166", pos=(0,38), scale=soft_pulse)]
l += [layer("Flame core", ellipse(54,82), "#FFF2B2", pos=(0,108), scale=soft_pulse)]
specs.append(make_tgs("fire.tgs","🔥","Ngọn lửa",l))

# Check: green disc, bright white check with stroke.
l=[]
l += [layer("Check badge", ellipse(358,358), "#2FCB83", "both", scale=pulse, outline="#138B5C", outline_w=18)]
l += [layer("Check mark", path([(-106,6),(-42,72),(116,-96)],False), "#FFFFFF", mode="stroke", outline="#FFFFFF", outline_w=34)]
specs.append(make_tgs("check.tgs","✅","Thành công",l))

# Warning: amber triangle and dark outline, exclamation.
l=[]
l += [layer("Warning triangle", path([(0,-192),(196,150),(-196,150)],True), "#FFC247", "both", scale=pulse, outline="#8C5815", outline_w=18)]
l += [layer("Warning bar", rect(34,132,17), "#513B29", pos=(0,-18))]
l += [layer("Warning dot", ellipse(38,38), "#513B29", pos=(0,86))]
specs.append(make_tgs("warning.tgs","⚠️","Cảnh báo",l))

# Megaphone: stylized horn and sound waves.
l=[]
l += [layer("Megaphone body", path([(-152,-76),(54,-142),(54,142),(-152,76)],True), "#66D9F0", "both", scale=pulse, outline="#176A93", outline_w=18)]
l += [layer("Megaphone mouth", path([(54,-142),(180,-194),(180,194),(54,142)],True), "#B7F1FF", "both", outline="#176A93", outline_w=16)]
l += [layer("Megaphone handle", path([(-92,64),(-20,64),(32,186),(-42,198)],True), "#387EBE", "both", pos=(0,4), outline="#174B7C", outline_w=12)]
l += [layer("Sound wave 1", path([(0,-64),(34,-26),(34,26),(0,64)],False), "#FFFFFF", mode="stroke", pos=(144,0), rotation=wiggle, outline="#FFFFFF", outline_w=18)]
l += [layer("Sound wave 2", path([(0,-104),(62,-42),(62,42),(0,104)],False), "#FFFFFF", mode="stroke", pos=(182,0), rotation=wiggle, outline="#FFFFFF", outline_w=18)]
specs.append(make_tgs("megaphone.tgs","📢","Thông báo",l))

# Ticket: violet ticket with two circular punches and a light diagonal stripe.
l=[]
l += [layer("Ticket base", rect(350,236,42), "#8E75F0", "both", scale=pulse, outline="#47319A", outline_w=18)]
l += [layer("Ticket stripe", rect(18,180,9), "#E5DBFF", pos=(-42,0))]
l += [layer("Ticket punch left", ellipse(50,50), "#FFFFFF", pos=(-148,0), scale=soft_pulse)]
l += [layer("Ticket punch right", ellipse(50,50), "#FFFFFF", pos=(148,0), scale=soft_pulse)]
l += [layer("Ticket sparkle", path([(0,-52),(13,-13),(52,0),(13,13),(0,52),(-13,13),(-52,0),(-13,-13)],True), "#FFE38C", pos=(64,0), scale=soft_pulse)]
specs.append(make_tgs("ticket.tgs","🎟️","Vé thưởng",l))

# Bank card: teal card with gold stripe and a coin chip.
l=[]
l += [layer("Card body", rect(362,246,38), "#2AB7A9", "both", scale=pulse, outline="#126F69", outline_w=18)]
l += [layer("Card top stripe", rect(324,54,14), "#155C67", pos=(0,-72))]
l += [layer("Card chip", rect(76,58,12), "#FFD166", pos=(-106,24), outline="#B57A17", mode="both", outline_w=8)]
l += [layer("Card number line", rect(126,18,9), "#E0FFF9", pos=(76,74))]
specs.append(make_tgs("bank_card.tgs","💳","Thẻ ngân hàng",l))

# Shield: navy shield, teal inset and check.
l=[]
l += [layer("Shield base", path([(0,-190),(162,-124),(150,44),(80,152),(0,204),(-80,152),(-150,44),(-162,-124)],True), "#377BD6", "both", scale=pulse, outline="#17417F", outline_w=18)]
l += [layer("Shield inset", path([(0,-132),(108,-90),(100,32),(48,112),(0,148),(-48,112),(-100,32),(-108,-90)],True), "#5CCDB2")]
l += [layer("Shield check", path([(-66,0),(-18,48),(78,-58)],False), "#FFFFFF", mode="stroke", outline="#FFFFFF", outline_w=28)]
specs.append(make_tgs("shield.tgs","🛡️","Bảo vệ",l))

# Extra menu icons for user/admin navigation.
# People: a pair of friendly silhouettes.
l=[]
l += [layer("People rear head", ellipse(104,104), "#69C6F5", pos=(78,-84), scale=soft_pulse)]
l += [layer("People rear shoulders", path([(22,32),(42,-12),(114,-28),(180,14),(190,72),(20,72)],True), "#69C6F5", pos=(24,48))]
l += [layer("People front head", ellipse(128,128), "#FFD166", pos=(-54,-80), scale=pulse, outline="#98631B", outline_w=10)]
l += [layer("People front shoulders", path([(-206,112),(-178,8),(-98,-30),(-20,8),(10,112)],True), "#F5A94D", pos=(-32,10), outline="#98631B", mode="both", outline_w=10)]
specs.append(make_tgs("users.tgs","👥","Người chơi",l))

# Analytics chart: bars and rising arrow.
l=[]
l += [layer("Chart panel", rect(360,300,34), "#EAF4FF", "both", scale=pulse, outline="#3262A3", outline_w=16)]
l += [layer("Chart bar one", rect(48,100,12), "#63B3ED", pos=(-104,54))]
l += [layer("Chart bar two", rect(48,158,12), "#52C9A5", pos=(-20,25))]
l += [layer("Chart bar three", rect(48,206,12), "#FFBE55", pos=(64,1))]
l += [layer("Chart rising line", path([(-144,-82),(-42,-130),(46,-88),(144,-160)],False), "#2463A6", mode="stroke", outline="#2463A6", outline_w=16)]
l += [layer("Chart arrow head", path([(144,-160),(82,-154),(126,-100)],True), "#2463A6")]
specs.append(make_tgs("chart.tgs","📊","Thống kê",l))

# Scroll: parchment and curled ends.
l=[]
l += [layer("Scroll paper", rect(256,340,22), "#FFE6A6", "both", scale=pulse, outline="#9A6B2C", outline_w=16)]
l += [layer("Scroll top", rect(310,54,25), "#F8C76A", "both", pos=(0,-158), outline="#9A6B2C", outline_w=12)]
l += [layer("Scroll bottom", rect(310,54,25), "#F8C76A", "both", pos=(0,158), outline="#9A6B2C", outline_w=12)]
for yy, ww in [(-70,154),(-12,178),(46,150)]:
    l.append(layer("Scroll writing", rect(ww,12,6), "#B98746", pos=(0,yy)))
specs.append(make_tgs("scroll.tgs","📜","Lịch sử",l))

# Open book: two facing pages and a navy spine.
l=[]
l += [layer("Book left page", path([(-8,-152),(-174,-190),(-174,126),(-8,168)],True), "#E9F4FF", "both", scale=pulse, outline="#34577F", outline_w=14)]
l += [layer("Book right page", path([(8,-152),(174,-190),(174,126),(8,168)],True), "#FFF4D6", "both", outline="#34577F", outline_w=14)]
l += [layer("Book spine", rect(22,318,10), "#4777B8")]
l += [layer("Book left writing", rect(82,12,6), "#9CB8D5", pos=(-88,-72))]
l += [layer("Book right writing", rect(82,12,6), "#D5B77B", pos=(88,-72))]
specs.append(make_tgs("book.tgs","📖","Sổ tay",l))

# Link: two interlocking rings.
l=[]
l += [layer("Link ring left", path([(-84,-82),(-128,-82),(-170,-40),(-170,34),(-128,76),(-54,76),(-8,32)],False), "#5ED6C3", mode="stroke", scale=pulse, outline="#157B77", outline_w=34)]
l += [layer("Link ring right", path([(84,82),(128,82),(170,40),(170,-34),(128,-76),(54,-76),(8,-32)],False), "#74B8FF", mode="stroke", outline="#245AA1", outline_w=34)]
l += [layer("Link connector", path([(-54,48),(54,-48)],False), "#FFFFFF", mode="stroke", outline="#FFFFFF", outline_w=30)]
specs.append(make_tgs("link.tgs","🔗","Liên kết",l))

# Trophy: golden cup with handles, stem and base.
l=[]
l += [layer("Trophy cup", path([(-126,-154),(126,-154),(102,16),(42,92),(-42,92),(-102,16)],True), "#FFD166", "both", scale=pulse, outline="#94600D", outline_w=16)]
l += [layer("Trophy left handle", path([(-126,-112),(-208,-132),(-204,-28),(-116,8)],False), "#FFCF65", mode="stroke", outline="#94600D", outline_w=24)]
l += [layer("Trophy right handle", path([(126,-112),(208,-132),(204,-28),(116,8)],False), "#FFCF65", mode="stroke", outline="#94600D", outline_w=24)]
l += [layer("Trophy stem", rect(48,92,14), "#E5A52C", pos=(0,120))]
l += [layer("Trophy foot", rect(176,38,14), "#C8871C", pos=(0,176))]
l += [layer("Trophy shine", path([(0,-110),(18,-58),(70,-40),(18,-22),(0,30),(-18,-22),(-70,-40),(-18,-58)],True), "#FFF2B4", pos=(0,-46), scale=soft_pulse)]
specs.append(make_tgs("trophy.tgs","🏆","Cúp chiến thắng",l))

# Receipt: pale slip with folded top and check mark.
l=[]
l += [layer("Receipt paper", path([(-140,-180),(140,-180),(140,160),(102,142),(64,160),(26,142),(-12,160),(-50,142),(-88,160),(-140,142)],True), "#F8FBFF", "both", scale=pulse, outline="#607A99", outline_w=14)]
for yy, ww in [(-100,166),(-38,194),(24,152)]:
    l.append(layer("Receipt line", rect(ww,14,7), "#A5B6C8", pos=(-8,yy)))
l += [layer("Receipt check", path([(28,76),(62,108),(122,36)],False), "#27B77A", mode="stroke", outline="#27B77A", outline_w=20)]
specs.append(make_tgs("receipt.tgs","🧾","Hóa đơn",l))

# Cash with wings: a gold note and light wings.
l=[]
l += [layer("Cash note", rect(230,150,28), "#69D79F", "both", scale=pulse, outline="#176B50", outline_w=16)]
l += [layer("Cash coin", ellipse(82,82), "#FFD166", "both", outline="#A56C10", outline_w=10)]
l += [layer("Cash wing left", path([(0,-28),(-96,-98),(-62,-20),(-106,26),(-8,54)],True), "#EAF7FF", "both", pos=(-110,0), outline="#6D9FB9", outline_w=10)]
l += [layer("Cash wing right", path([(0,-28),(96,-98),(62,-20),(106,26),(8,54)],True), "#EAF7FF", "both", pos=(110,0), outline="#6D9FB9", outline_w=10)]
specs.append(make_tgs("cash.tgs","💸","Tiền thưởng",l))

# Bell: golden bell with swinging clapper.
l=[]
l += [layer("Bell dome", path([(-132,72),(-112,-48),(-64,-126),(0,-148),(64,-126),(112,-48),(132,72)],True), "#FFD166", "both", scale=pulse, outline="#99600E", outline_w=16)]
l += [layer("Bell rim", rect(286,28,14), "#E9A52A", pos=(0,86), outline="#99600E", mode="both", outline_w=10)]
l += [layer("Bell clapper", ellipse(44,44), "#E9A52A", pos=(0,140), rotation=wiggle)]
l += [layer("Bell shine", ellipse(28,58), "#FFF3C4", pos=(-62,-42))]
specs.append(make_tgs("bell.tgs","🔔","Chuông",l))

# Muted bell: same bell plus a diagonal slash.
l=[]
l += [layer("Mute bell dome", path([(-132,72),(-112,-48),(-64,-126),(0,-148),(64,-126),(112,-48),(132,72)],True), "#B6C5D6", "both", scale=pulse, outline="#566B82", outline_w=16)]
l += [layer("Mute bell rim", rect(286,28,14), "#7D90A5", pos=(0,86), outline="#566B82", mode="both", outline_w=10)]
l += [layer("Mute slash", path([(-176,-170),(176,170)],False), "#E75B5B", mode="stroke", outline="#E75B5B", outline_w=32)]
specs.append(make_tgs("mute.tgs","🔕","Tắt thông báo",l))

# Status/action icons used on transaction and player-management buttons.
l=[]
l += [layer("Reject badge", ellipse(350,350), "#F05A67", "both", scale=pulse, outline="#992B3B", outline_w=18)]
l += [layer("Reject cross", path([(-92,-92),(92,92)],False), "#FFFFFF", mode="stroke", outline="#FFFFFF", outline_w=34)]
l += [layer("Reject cross second", path([(-92,92),(92,-92)],False), "#FFFFFF", mode="stroke", outline="#FFFFFF", outline_w=34)]
specs.append(make_tgs("cross_mark.tgs","❌","Từ chối",l))

l=[]
l += [layer("Stop sign", path([(-80,-182),(80,-182),(182,-80),(182,80),(80,182),(-80,182),(-182,80),(-182,-80)],True), "#EF4B4B", "both", scale=pulse, outline="#8E2525", outline_w=18)]
l += [layer("Stop bar", rect(178,42,18), "#FFFFFF")]
specs.append(make_tgs("stop.tgs","🛑","Dừng",l))

l=[]
l += [layer("Block badge", ellipse(350,350), "#F7F9FC", "both", scale=pulse, outline="#E04C5A", outline_w=24)]
l += [layer("Block slash", path([(-154,154),(154,-154)],False), "#E04C5A", mode="stroke", outline="#E04C5A", outline_w=42)]
specs.append(make_tgs("prohibited.tgs","🚫","Chặn",l))

l=[]
l += [layer("Unlock body", rect(238,176,32), "#53C9A5", "both", pos=(0,72), scale=pulse, outline="#176E59", outline_w=16)]
l += [layer("Unlock shackle", path([(-74,12),(-74,-82),(-48,-142),(24,-166),(92,-122),(92,-54)],False), "#FFD166", mode="stroke", outline="#8C641C", outline_w=34)]
l += [layer("Unlock keyhole", ellipse(34,34), "#FFFFFF", pos=(0,72))]
specs.append(make_tgs("unlock.tgs","🔓","Mở khóa",l))

for s in specs:
    print(f"{s['emoji']} {s['title']}: {s['file']} ({s['bytes']} bytes)")

# Build a machine-readable manifest used by the uploader.
manifest = {
    "title": "Koka Game • Animated Emoji",
    "short_prefix": "koka_game_emoji",
    "stickers": [{"file": s["file"], "emoji": s["emoji"], "title": s["title"]} for s in specs]
}
(OUT / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
