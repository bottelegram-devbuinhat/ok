"""Koka Game animated Telegram stickers (regular TGS stickers; no Premium needed).

The bot can send a TGS file directly at any time. /taosticker optionally creates
an addable regular sticker set for the admin using Telegram Bot API.
"""
from __future__ import annotations

import asyncio
import json
import logging
import re
from pathlib import Path
from typing import Any

import requests

from config import c

BASE_DIR = Path(__file__).resolve().parent
STICKER_DIR = BASE_DIR / "sticker_pack"
MANIFEST_PATH = STICKER_DIR / "manifest.json"
FILE_IDS_PATH = STICKER_DIR / "file_ids.json"
BOT_API = "https://api.telegram.org/bot{token}/{method}"


def load_manifest() -> dict[str, Any]:
    try:
        value = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
        if not isinstance(value, dict) or not isinstance(value.get("stickers"), list):
            raise ValueError("Sticker manifest không đúng cấu trúc")
        return value
    except (OSError, ValueError, TypeError):
        return {"title": "Koka Game • Sticker Động", "short_prefix": "koka_game_stickers", "stickers": []}


def load_file_ids() -> dict[str, str]:
    try:
        payload = json.loads(FILE_IDS_PATH.read_text(encoding="utf-8"))
        values = payload.get("file_ids", {})
        if isinstance(values, dict):
            return {str(key): str(value) for key, value in values.items() if key and value}
    except (OSError, ValueError, TypeError):
        pass
    return {}


def _save_file_ids(name: str, file_ids: dict[str, str]) -> None:
    payload = {
        "pack_name": name,
        "pack_url": f"https://t.me/addstickers/{name}",
        "file_ids": file_ids,
    }
    temp = FILE_IDS_PATH.with_suffix(".json.tmp")
    temp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    temp.replace(FILE_IDS_PATH)


def _api(token: str, method: str, *, data=None, files=None):
    response = requests.post(
        BOT_API.format(token=token, method=method),
        data=data,
        files=files,
        timeout=(15, 120),
    )
    try:
        result = response.json()
    except ValueError:
        response.raise_for_status()
        raise RuntimeError(f"Telegram API {method} trả về dữ liệu không hợp lệ.")
    if not result.get("ok"):
        # Telegram returns useful descriptions (including STICKERSET_INVALID)
        # with HTTP 400; inspect the Bot API payload before raising HTTPError.
        raise RuntimeError(result.get("description", f"Telegram API {method} thất bại"))
    response.raise_for_status()
    return result.get("result")


def _sticker_set_name(username: str) -> str:
    clean = re.sub(r"[^A-Za-z0-9_]", "", username).lower().strip("_")
    if not clean:
        raise RuntimeError("Không lấy được username hợp lệ của bot.")
    prefix = str(load_manifest().get("short_prefix", "koka_game_stickers"))
    name = f"{prefix}_by_{clean}"
    if len(name) > 64:
        name = f"koka_stk_by_{clean}"
    if len(name) > 64 or "__" in name:
        raise RuntimeError("Username bot quá dài để tạo tên sticker set hợp lệ.")
    return name


def _get_sticker_set(token: str, name: str):
    return _api(token, "getStickerSet", data={"name": name})


def _create_or_fetch_pack(token: str, owner_id: int) -> tuple[str, dict[str, str]]:
    me = _api(token, "getMe")
    username = me.get("username") or ""
    name = _sticker_set_name(username)
    manifest = load_manifest()
    entries = manifest["stickers"]
    if not entries:
        raise RuntimeError("Không có sticker trong sticker_pack/manifest.json.")

    try:
        sticker_set = _get_sticker_set(token, name)
    except RuntimeError as exc:
        description = str(exc).lower()
        if not any(marker in description for marker in ("stickerset_invalid", "sticker set not found", "not found")):
            raise
        sticker_set = None

    if sticker_set is None:
        sticker_payload = []
        file_handles = []
        upload_files = {}
        try:
            for index, entry in enumerate(entries):
                path = STICKER_DIR / entry["file"]
                if not path.is_file():
                    raise FileNotFoundError(f"Thiếu tệp sticker {path.name}.")
                attach_name = f"sticker_{index}"
                sticker_payload.append({
                    "sticker": f"attach://{attach_name}",
                    "format": "animated",
                    "emoji_list": [entry["emoji"]],
                    "keywords": ["koka", "game", str(entry.get("key", "sticker"))[:20]],
                })
                handle = path.open("rb")
                file_handles.append(handle)
                upload_files[attach_name] = (path.name, handle, "application/x-tgsticker")
            _api(
                token,
                "createNewStickerSet",
                data={
                    "user_id": int(owner_id),
                    "name": name,
                    "title": manifest.get("title", "Koka Game • Sticker Động"),
                    "sticker_type": "regular",
                    "stickers": json.dumps(sticker_payload, ensure_ascii=False),
                },
                files=upload_files,
            )
        finally:
            for handle in file_handles:
                handle.close()
        sticker_set = _get_sticker_set(token, name)

    stickers = sticker_set.get("stickers", [])
    file_ids: dict[str, str] = {}
    key_by_emoji = {str(entry.get("emoji")): str(entry.get("key") or entry["file"]) for entry in entries}
    # Prefer the sticker's emoji attribute so manual reordering of the pack
    # does not mismatch local animation keys. Fall back to creation order.
    for sticker in stickers:
        emoji = str(sticker.get("emoji") or "")
        file_id = sticker.get("file_id")
        if emoji in key_by_emoji and file_id:
            file_ids[key_by_emoji[emoji]] = str(file_id)
    for entry, sticker in zip(entries, stickers):
        file_id = sticker.get("file_id")
        key = str(entry.get("key") or entry["file"])
        if file_id:
            file_ids.setdefault(key, str(file_id))
    if not file_ids:
        raise RuntimeError("Telegram không trả về file_id của sticker. Hãy thử /taosticker lại.")
    _save_file_ids(name, file_ids)
    return name, file_ids


async def send_koka_sticker(bot, chat_id: int | str, key: str) -> bool:
    """Send one animated sticker; fail softly so game/banking actions continue."""
    manifest = load_manifest()
    entry = next((item for item in manifest.get("stickers", []) if item.get("key") == key), None)
    if not entry:
        logging.warning("Unknown Koka sticker key: %s", key)
        return False

    file_id = load_file_ids().get(key)
    sticker = file_id or (STICKER_DIR / entry["file"])
    try:
        await bot.send_sticker(chat_id=chat_id, sticker=sticker, emoji=entry.get("emoji"))
        return True
    except Exception as first_error:
        # If a cached file_id became invalid after a pack was changed, retry by
        # uploading the local TGS asset. Failure never interrupts the main flow.
        if file_id:
            try:
                await bot.send_sticker(
                    chat_id=chat_id,
                    sticker=STICKER_DIR / entry["file"],
                    emoji=entry.get("emoji"),
                )
                return True
            except Exception as second_error:
                logging.warning("Koka sticker send failed (%s): %s", key, second_error)
                return False
        logging.warning("Koka sticker send failed (%s): %s", key, first_error)
        return False


async def cmd_sticker_setup(update, context):
    """Create a normal animated sticker set owned by the calling admin."""
    user = update.effective_user
    message = update.effective_message
    admins = {int(value) for value in c.get("admin_ids", [])}
    if not user or user.id not in admins:
        if message:
            await message.reply_text("⛔ Bạn không có quyền tạo bộ sticker Koka.")
        return

    token = str(c.get("token") or "").strip()
    if not token:
        await message.reply_text("❌ Bot chưa có TELEGRAM_BOT_TOKEN hợp lệ.")
        return

    await message.reply_text("🎨 Đang chuẩn bị bộ sticker động Koka trên Telegram...")
    try:
        name, file_ids = await asyncio.to_thread(_create_or_fetch_pack, token, user.id)
        await message.reply_text(
            "✅ <b>Đã sẵn sàng bộ sticker động Koka!</b>\n"
            f"<a href=\"https://t.me/addstickers/{name}\">Thêm bộ sticker Koka vào Telegram</a>\n"
            f"Đồng bộ {len(file_ids)}/{len(load_manifest()['stickers'])} sticker.\n\n"
            "Bot cũng có thể tự gửi sticker trong lời chào, lì xì và kết quả cược. "
            "Tính năng sticker thường không yêu cầu Telegram Premium.",
            parse_mode="HTML",
            disable_web_page_preview=True,
        )
    except Exception as exc:
        logging.exception("Could not create Koka animated sticker set")
        await message.reply_text(
            "❌ <b>Chưa tạo được bộ sticker.</b>\n"
            f"Chi tiết: <code>{str(exc)[:600]}</code>\n\n"
            "Bạn vẫn có thể dùng sticker gửi trực tiếp từ file TGS; hãy kiểm tra token, "
            "quyền truy cập mạng và thử lại.",
            parse_mode="HTML",
        )
