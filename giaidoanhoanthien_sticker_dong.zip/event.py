"""Sự kiện lì xì: ngân sách và trạng thái được lưu bền vững trong events.json."""
import asyncio
import json
import os
import secrets
from datetime import datetime, timedelta, timezone

EVENT_FILE = "events.json"
_lock = asyncio.Lock()

def _load():
    try:
        with open(EVENT_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
            return data if isinstance(data, dict) else {}
    except (OSError, json.JSONDecodeError):
        return {}

def _save(data):
    tmp = EVENT_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, EVENT_FILE)

def create_event(total_amount: int, duration_minutes: int, admin_id: int):
    if not (1000 <= total_amount <= 1_000_000_000):
        raise ValueError("Ngân sách phải từ 1.000đ đến 1.000.000.000đ.")
    if not (1 <= duration_minutes <= 10080):
        raise ValueError("Thời gian phải từ 1 đến 10.080 phút.")
    data = _load()
    now = datetime.now(timezone.utc)
    data["active"] = {
        "id": secrets.token_hex(4).upper(),
        "total": total_amount, "remaining": total_amount,
        "duration_minutes": duration_minutes,
        "created_at": now.isoformat(),
        "expires_at": (now + timedelta(minutes=duration_minutes)).isoformat(),
        "creator": int(admin_id), "claimed": {}
    }
    _save(data)
    return data["active"]

async def claim_event(user_id: int):
    async with _lock:
        data = _load()
        ev = data.get("active")
        if not ev:
            return None, "Hiện chưa có sự kiện lì xì."
        now = datetime.now(timezone.utc)
        try:
            expires = datetime.fromisoformat(ev["expires_at"])
        except (KeyError, ValueError):
            return None, "Sự kiện không hợp lệ."
        if now >= expires:
            return None, "Sự kiện lì xì đã kết thúc."
        uid = str(user_id)
        if uid in ev.setdefault("claimed", {}):
            return None, "Bạn đã nhận lì xì trong sự kiện này rồi."
        remaining = int(ev.get("remaining", 0))
        if remaining <= 0:
            return None, "Lì xì đã hết ngân sách."
        # Mỗi lượt nhận ngẫu nhiên 1–20% ngân sách còn lại, tối thiểu 1đ.
        total = max(1, int(ev.get("total", remaining)))
        upper = max(1, min(remaining, (total * 20 + 99) // 100))
        lower = max(1, min(upper, (total + 99) // 100))
        reward = secrets.randbelow(upper - lower + 1) + lower
        ev["remaining"] = remaining - reward
        ev["claimed"][uid] = {"amount": reward, "at": now.isoformat()}
        _save(data)
        return {"amount": reward, "remaining": ev["remaining"], "event_id": ev["id"]}, None
