"""Legacy UI helper kept for compatibility with the original project.

Koka now uses ordinary animated TGS stickers (sticker_pack/) rather than
Telegram Custom Emoji, so keyboard labels remain standard Unicode text.
"""
from __future__ import annotations

import json
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
MANIFEST_PATH = BASE_DIR / "emoji_pack" / "manifest.json"


def _known_emojis() -> list[str]:
    try:
        entries = json.loads(MANIFEST_PATH.read_text(encoding="utf-8")).get("stickers", [])
        return [str(item["emoji"]) for item in entries if item.get("emoji")]
    except (OSError, ValueError, TypeError, KeyError):
        return []


def _split_leading_emoji(label: str):
    for emoji in sorted(_known_emojis(), key=len, reverse=True):
        if label.startswith(emoji):
            return emoji, label[len(emoji):].lstrip()
    return None, label


def menu_text_matches(incoming: str, original_label: str) -> bool:
    """Accept both a full menu label and its text without the leading emoji."""
    emoji, clean_label = _split_leading_emoji(original_label)
    return incoming == original_label or (emoji is not None and incoming == clean_label)


def make_keyboard_button(label: str, **kwargs):
    """Use regular Unicode labels; Telegram buttons do not play TGS animations."""
    from telegram import KeyboardButton
    return KeyboardButton(text=label, **kwargs)


def make_inline_button(label: str, **kwargs):
    """Use regular Unicode labels; Telegram buttons do not play TGS animations."""
    from telegram import InlineKeyboardButton
    return InlineKeyboardButton(text=label, **kwargs)
