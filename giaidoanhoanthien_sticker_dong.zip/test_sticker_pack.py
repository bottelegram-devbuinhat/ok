"""Offline checks for Koka's standard animated Telegram sticker pack."""
import asyncio
import gzip
import json
from pathlib import Path
from unittest.mock import patch

import sticker_pack

ROOT = Path(__file__).resolve().parent


def test_all_tgs_assets_match_telegram_limits():
    manifest = sticker_pack.load_manifest()
    assert len(manifest["stickers"]) == 27
    for entry in manifest["stickers"]:
        path = sticker_pack.STICKER_DIR / entry["file"]
        assert path.is_file()
        compressed = path.read_bytes()
        assert len(compressed) <= 64 * 1024
        data = json.loads(gzip.decompress(compressed).decode("utf-8"))
        assert (data["w"], data["h"]) == (512, 512)
        assert 30 <= data["fr"] <= 60
        assert 0 < data["op"] - data["ip"] <= 180
        assert (data["op"] - data["ip"]) / data["fr"] <= 3
        assert data["layers"]
        assert any(layer.get("ks", {}).get("s", {}).get("a") == 1 for layer in data["layers"])


def test_send_sticker_uses_local_tgs_without_premium():
    class FakeBot:
        def __init__(self):
            self.calls = []

        async def send_sticker(self, **kwargs):
            self.calls.append(kwargs)

    bot = FakeBot()
    ok = asyncio.run(sticker_pack.send_koka_sticker(bot, 12345, "dice"))
    assert ok is True
    assert len(bot.calls) == 1
    assert bot.calls[0]["chat_id"] == 12345
    assert Path(bot.calls[0]["sticker"]).suffix == ".tgs"


def test_send_sticker_retries_local_file_if_cached_file_id_is_invalid(tmp_path):
    original = sticker_pack.FILE_IDS_PATH
    sticker_pack.FILE_IDS_PATH = tmp_path / "file_ids.json"
    sticker_pack.FILE_IDS_PATH.write_text(json.dumps({"file_ids": {"dice": "bad-file-id"}}), encoding="utf-8")

    class FakeBot:
        def __init__(self):
            self.calls = []

        async def send_sticker(self, **kwargs):
            self.calls.append(kwargs["sticker"])
            if len(self.calls) == 1:
                raise RuntimeError("wrong file identifier")

    try:
        bot = FakeBot()
        ok = asyncio.run(sticker_pack.send_koka_sticker(bot, 12345, "dice"))
        assert ok is True
        assert bot.calls[0] == "bad-file-id"
        assert isinstance(bot.calls[1], Path)
    finally:
        sticker_pack.FILE_IDS_PATH = original


def test_regular_sticker_set_upload_payload_is_not_custom_emoji(tmp_path):
    original_path = sticker_pack.FILE_IDS_PATH
    sticker_pack.FILE_IDS_PATH = tmp_path / "file_ids.json"
    manifest = sticker_pack.load_manifest()
    expected_entries = manifest["stickers"]
    calls = []

    class FakeResponse:
        def __init__(self, payload):
            self.payload = payload

        def raise_for_status(self):
            return None

        def json(self):
            return self.payload

    def fake_post(url, data=None, files=None, timeout=None):
        method = url.rsplit("/", 1)[-1]
        calls.append((method, data, files))
        if method == "getMe":
            return FakeResponse({"ok": True, "result": {"username": "KokaGameBot"}})
        if method == "getStickerSet" and len([c for c in calls if c[0] == method]) == 1:
            return FakeResponse({"ok": False, "description": "Bad Request: STICKERSET_INVALID"})
        if method == "createNewStickerSet":
            return FakeResponse({"ok": True, "result": True})
        if method == "getStickerSet":
            return FakeResponse({"ok": True, "result": {"stickers": [{"file_id": f"file_{i}"} for i in range(len(expected_entries))]}})
        raise AssertionError(method)

    try:
        with patch.object(sticker_pack.requests, "post", side_effect=fake_post):
            name, file_ids = sticker_pack._create_or_fetch_pack("123:TEST", 12345)
        create_call = next(call for call in calls if call[0] == "createNewStickerSet")
        payload = json.loads(create_call[1]["stickers"])
        assert create_call[1]["sticker_type"] == "regular"
        assert len(payload) == 27
        assert all(item["format"] == "animated" for item in payload)
        assert len(create_call[2]) == 27
        assert name.endswith("_by_kokagamebot")
        assert len(file_ids) == 27
        saved = json.loads(sticker_pack.FILE_IDS_PATH.read_text(encoding="utf-8"))
        assert saved["pack_name"] == name
    finally:
        sticker_pack.FILE_IDS_PATH = original_path
