import logging # l
import os # o
import asyncio # a
import traceback # tb
from html import escape
from telegram import Update, ReplyKeyboardMarkup, InlineKeyboardMarkup # t
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, ContextTypes, filters # e

import bxh # bxh
from config import c, u, g, f_w, p, q, t_f # cfg
from game import chay_vong_quay_game # g
from notif import cmd_tat_tb, cmd_bat_tb, ds_tat_tb # nf
from wallet import cmd_nap, cmd_cong, cmd_tru, cmd_rut, cmd_duyet, cmd_tuchoi
from giftcode import cmd_crcode, cmd_duyetcode, xu_ly_nhap_code, check_code # gc
from admin import cmd_addadmin, cmd_kickadmin, ghi_log_tat_bot # ad
from utils import gui_huong_dan # ut
from history import xem_lich_su_user, xem_lich_su_admin # hs
from custom_emojis import make_keyboard_button, make_inline_button, menu_text_matches
from sticker_pack import cmd_sticker_setup, send_koka_sticker
import wallet # w
from firebase_logger import ghi_log_loi, ghi_log_admin, ghi_log_wallet, ghi_log_game # fgl
from datetime import datetime
import secrets
from zoneinfo import ZoneInfo
from event import create_event, claim_event
from giftcode import pending_codes, save_pending_codes

COMPOSING_ADMINS = set()

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO) # log

def g_u(i, n=""): # gu
    s = str(i) # s
    if s not in u: u[s] = {}
    dv = { # dv
        "name": n,
        "balance": c.get("default_balance", 1000),
        "wins": 0,
        "bets_count": 0,
        "refs": 0,
        "referrals": [],
        "referred_by": None,
        "ref_earnings": 0,
        "blocked": False,
        "current_bet": None,
        "history": [],
        "nhan_thong_bao": False
    }
    x = False # x
    for k in dv:
        if k not in u[s]:
            u[s][k] = dv[k]
            x = True
    if x: f_w(p, u)
    return u[s]

async def c_s(u_obj: Update, x_obj: ContextTypes.DEFAULT_TYPE): # cs
    i = u_obj.effective_user.id # i
    name = u_obj.effective_user.first_name # name
    w = g_u(i, name) # w
    try:
        parts = (u_obj.message.text or "").split(maxsplit=1)
        referrer = parts[1].strip() if len(parts) > 1 else ""
        my_id = str(i)
        if referrer.isdigit() and referrer != my_id and referrer in u and not w.get("referred_by"):
            referral_list = u[referrer].setdefault("referrals", [])
            if my_id not in referral_list:
                w["referred_by"] = referrer
                referral_list.append(my_id)
                u[referrer]["refs"] = len(referral_list)
                f_w(p, u)
                ghi_log_wallet(referrer, "REFERRAL_REGISTERED", f"New referral {my_id}", referred_user=my_id)
                ghi_log_wallet(my_id, "REFERRED_BY", f"Referred by {referrer}", referrer_id=referrer)
    except Exception as exc:
        ghi_log_loi(f"Referral attribution failed: {type(exc).__name__}: {exc}", user_id=str(i))
    ghi_log_wallet(i, "START", "User opened bot", is_admin=(i in c.get("admin_ids", [])))
    if w["blocked"]:
        await u_obj.message.reply_text("⛔ Tài khoản bị khóa. Vui lòng liên hệ admin: https://t.me/koka113", parse_mode="HTML")
        return

    await send_koka_sticker(x_obj.bot, i, "crown" if i in c.get("admin_ids", []) else "dice")
    ss = f"#{c.get('session_id', 1):04d}" # ss
    if i in c["admin_ids"]:
        welcome_admin = ( # wa
            f"✨━━━━━━━━━━━━━━━━━━✨\n"
            f"👑 <b>TRUNG TÂM QUẢN TRỊ</b> 👑\n"
            f"✨━━━━━━━━━━━━━━━━━━✨\n"
            f"• Xin chào Admin: <b>{escape(str(name))}</b>\n"
            f"• ID Telegram: <code>{i}</code>\n"
            f"• Trạng thái phiên hiện tại: <b>{ss}</b>\n\n"
            f"💡 <i>Sử dụng các công cụ quản trị game để vận hành.</i>"
        )
        k = ReplyKeyboardMarkup([ # k
            [make_keyboard_button("👥 Quản lý người chơi"), make_keyboard_button("👑 Quản lý Admin")],
            [make_keyboard_button("🎟️ Tạo code"), make_keyboard_button("📜 Lịch sử Server & Code")],
            [make_keyboard_button("💰 Cộng/Trừ tiền"), make_keyboard_button("📊 Thống kê hệ thống")],
            [make_keyboard_button("🧾 Quản lý giao dịch"), make_keyboard_button("🎁 Quản lý lì xì")],
            [make_keyboard_button("📢 Soạn thông báo")],
            [make_keyboard_button("🧾 Hủy phiên & hoàn cược")],
            [make_keyboard_button("📖 Hướng dẫn Admin"), make_keyboard_button("🛑 Tắt bot")]
        ], resize_keyboard=True)
        await u_obj.message.reply_text(welcome_admin, reply_markup=k, parse_mode="HTML")
    else:
        st = "🟢 Đang mở" if c["bet_active"] else "🔴 Đang khóa" # st
        welcome_user = ( # wu
            f"🎲━━━━━━━━━━━━━━━━━━🎲\n"
            f"🌟 <b>CHÀO MỪNG BẠN ĐẾN SẢNH GAME</b> 🌟\n"
            f"🎲━━━━━━━━━━━━━━━━━━🎲\n"
            f"• Chào mừng: <b>{escape(str(name))}</b>\n"
            f"• Số dư khả dụng: <b>{w['balance']:,.0f} VNĐ</b>\n"
            f"• Phiên hiện tại: <b>{ss}</b> ({st})\n\n"
            f"💡 <i>Nhắn nhanh <code>T[số_tiền]</code> (Tài) hoặc <code>X[số_tiền]</code> (Xỉu) để tham gia đặt cược ngay!</i>"
        )
        k = ReplyKeyboardMarkup([ # k
            [make_keyboard_button("🎲 Sảnh game"), make_keyboard_button("💰 Thông tin tài khoản")],
            [make_keyboard_button("🔥 ALL IN")],
            [make_keyboard_button("💳 Nạp tiền"), make_keyboard_button("💸 Rút tiền")],
            [make_keyboard_button("🔗 Mời bạn"), make_keyboard_button("🏆 Bảng xếp hạng")],
            [make_keyboard_button("📜 Lịch sử cược cá nhân"), make_keyboard_button("🔕 Tắt/Bật thông báo")],
            [make_keyboard_button("🎟️ Nhập code"), make_keyboard_button("🎁 Nhận lì xì"), make_keyboard_button("📖 Hướng dẫn")]
        ], resize_keyboard=True)
        await u_obj.message.reply_text(welcome_user, reply_markup=k, parse_mode="HTML")

async def h_m(u_obj: Update, x_obj: ContextTypes.DEFAULT_TYPE): # hm
    m = u_obj.message.text.strip() # m
    i = u_obj.effective_user.id # i
    w = g_u(i, u_obj.effective_user.first_name) # w
    if w["blocked"]:
        await u_obj.message.reply_text("⛔ Tài khoản của bạn đang bị khóa. Vui lòng liên hệ quản trị viên.")
        return

    if i in COMPOSING_ADMINS and i in c.get("admin_ids", []):
        if m.strip().upper() in ("/HUYSOAN", "HUY", "CANCEL"):
            COMPOSING_ADMINS.discard(i)
            await u_obj.message.reply_text("Đã hủy soạn thông báo.")
            return
        COMPOSING_ADMINS.discard(i)
        sent = failed = 0
        for target_id, account in list(u.items()):
            if account.get("blocked", False) or str(target_id) in {str(aid) for aid in c.get("admin_ids", [])}:
                continue
            try:
                await x_obj.bot.send_message(chat_id=int(target_id), text=m)
                sent += 1
            except Exception as exc:
                failed += 1
                ghi_log_loi(f"Broadcast failed: {type(exc).__name__}: {exc}", user_id=str(target_id))
        ghi_log_admin(i, "BROADCAST", f"Broadcast sent={sent}, failed={failed}")
        await u_obj.message.reply_text(f"📢 Đã phát thông báo. Thành công: {sent} | Thất bại: {failed}")
        return

    if menu_text_matches(m, "🔥 ALL IN") and i not in c.get("admin_ids", []):
        if not c.get("bet_active", False):
            await u_obj.message.reply_text("🔴 Phiên hiện đã khóa cược.")
        elif w.get("current_bet") is not None:
            await u_obj.message.reply_text("⚠️ Bạn đã đặt cược trong phiên này rồi.")
        elif int(w.get("balance", 0)) < 1000:
            await u_obj.message.reply_text("❌ Số dư cần tối thiểu 1.000đ để ALL IN.")
        else:
            kb = InlineKeyboardMarkup([[make_inline_button("🎲 ALL IN TÀI", callback_data="allin_TAI"),
                                        make_inline_button("🎲 ALL IN XỈU", callback_data="allin_XIU")]])
            await u_obj.message.reply_text(f"🔥 Số dư khả dụng: {int(w['balance']):,}đ\nChọn cửa để ALL IN:", reply_markup=kb)
        return

    if menu_text_matches(m, "🎁 Nhận lì xì") and i not in c.get("admin_ids", []):
        result, error = await claim_event(i)
        if error:
            await u_obj.message.reply_text("🎁 " + error)
        else:
            w["balance"] = int(w.get("balance", 0)) + result["amount"]
            f_w(p, u)
            ghi_log_wallet(i, "LUCKY_MONEY_CLAIM", f"Received {result['amount']} VND", amount=result["amount"], event_id=result["event_id"])
            await send_koka_sticker(x_obj.bot, i, "red_envelope")
            await u_obj.message.reply_text(f"🧧 Chúc mừng! Bạn nhận được <b>{result['amount']:,}đ</b>\nNgân sách lì xì còn: {result['remaining']:,}đ", parse_mode="HTML")
        return

    admin_only_menu = {
        "👥 Quản lý người chơi", "👑 Quản lý Admin", "🎟️ Tạo code",
        "📜 Lịch sử Server & Code", "💰 Cộng/Trừ tiền", "📊 Thống kê hệ thống",
        "🧾 Quản lý giao dịch", "🎁 Quản lý lì xì", "📢 Soạn thông báo",
        "🧾 Hủy phiên & hoàn cược", "🛑 Tắt bot"
    }
    if i not in c.get("admin_ids", []) and any(menu_text_matches(m, label) for label in admin_only_menu):
        await u_obj.message.reply_text("⛔ Bạn không còn hoặc không có quyền sử dụng chức năng này. Vui lòng liên hệ admin: https://t.me/koka113")
        return

    if i in c["admin_ids"]:
        if menu_text_matches(m, "🧾 Quản lý giao dịch"):
            await show_transaction_menu(u_obj.message); return
        elif menu_text_matches(m, "🎁 Quản lý lì xì"):
            await u_obj.message.reply_text("🎁 Tạo lì xì: <code>/lixi [tổng_ngân_sách] [thời_gian_phút]</code>\nVí dụ: <code>/lixi 500000 60</code>", parse_mode="HTML"); return
        elif menu_text_matches(m, "📢 Soạn thông báo"):
            COMPOSING_ADMINS.add(i)
            await u_obj.message.reply_text("📢 Gửi nội dung ở tin nhắn kế tiếp để phát đến toàn bộ người chơi. Gửi HUY để hủy.", parse_mode="HTML"); return
        elif menu_text_matches(m, "👥 Quản lý người chơi"):
            kl = [[make_inline_button(f"{str(vv.get('name', 'User'))[:24]} ({kk})", callback_data=f"us_view_{kk}")] for kk, vv in list(u.items())[:80]]
            # Tích hợp thêm 2 nút Duyệt nạp tiền và Duyệt rút tiền cho Admin theo yêu cầu trên ảnh
            await u_obj.message.reply_text(f"👥 <b>QUẢN LÝ NGƯỜI CHƠI</b> (hiển thị tối đa 80 tài khoản đầu tiên)", reply_markup=InlineKeyboardMarkup(kl), parse_mode="HTML")
            return
        elif menu_text_matches(m, "👑 Quản lý Admin"):
            await u_obj.message.reply_text(f"👑 <b>ADMINS</b>: <code>{c['admin_ids']}</code>\n• Thêm: <code>/addadmin [id]</code>\n• Kick: <code>/kickadmin [id]</code>", parse_mode="HTML")
            return
        elif menu_text_matches(m, "🎟️ Tạo code"):
            await u_obj.message.reply_text(
                "🎟️ <b>GIFTCODE</b>\n"
                "• Tạo ngẫu nhiên: <code>/autocode [số_mã] [tiền_mỗi_mã]</code>\n"
                "• Tạo mã riêng: <code>/crcode [mã] [số_lượt] [số_tiền]</code>\n"
                "Mọi mã mới cần duyệt trong Trung tâm quản lý giao dịch.",
                parse_mode="HTML")
            return
        elif menu_text_matches(m, "📜 Lịch sử Server & Code"):
            await xem_lich_su_admin(u_obj)
            return
        elif menu_text_matches(m, "💰 Cộng/Trừ tiền"):
            await u_obj.message.reply_text("💰 <b>ĐIỀU CHỈNH SỐ DƯ</b>\n• Cộng: <code>/cong [id] [tiền]</code>\n• Trừ: <code>/tru [id] [tiền]</code>\n• Duyệt rút và Giftcode: vào <b>Quản lý giao dịch</b>.\n• Hủy phiên: nút <b>Hủy phiên & hoàn cược</b>.", parse_mode="HTML")
            return
        elif menu_text_matches(m, "🧾 Hủy phiên & hoàn cược"):
            if not c.get("bet_active", False):
                await u_obj.message.reply_text("⚠️ Hiện không có phiên đang mở cược để hủy.", parse_mode="HTML")
                return
            c["cancel_round_requested"] = True
            f_w("config.json", c)
            ghi_log_admin(i, "ROUND_VOID_REQUESTED", f"Admin requested cancellation of session {c.get('session_id', 1)}")
            await u_obj.message.reply_text("🧾 Đã yêu cầu hủy phiên đang mở. Bot sẽ hoàn cược và ghi log khi xử lý phiên.", parse_mode="HTML")
            return
        elif menu_text_matches(m, "📊 Thống kê hệ thống"):
            tb = sum(acc.get("balance", 0) for acc in u.values()) # tb
            await u_obj.message.reply_text(f"📊 <b>THỐNG KÊ</b>\n• Tổng user: {len(u)}\n• Tổng tiền: <b>{tb:,.0f} VNĐ</b>", parse_mode="HTML")
            return
        elif menu_text_matches(m, "📖 Hướng dẫn Admin"):
            await gui_huong_dan(u_obj)
            return
        elif menu_text_matches(m, "🛑 Tắt bot"):
            ghi_log_tat_bot(i)
            await u_obj.message.reply_text("🛑 Đang tắt hệ thống...", parse_mode="HTML")
            os._exit(0)

    if menu_text_matches(m, "🎲 Sảnh game"):
        ss = f"#{c.get('session_id', 1):04d}" # ss
        st = "🟢 Mở" if c["bet_active"] else "🔴 Khóa" # st
        await u_obj.message.reply_text(f"🎲 <b>SẢNH - {ss}</b> ({st})\n• Nhắn <code>T[tiền]</code> hoặc <code>X[tiền]</code> (1k - 100k).", parse_mode="HTML")
    elif menu_text_matches(m, "💰 Thông tin tài khoản"):
        cb = w["current_bet"] # cb
        bs = f"{cb['type']} - {cb['amount']:,.0f}đ" if cb else "Chưa đặt" # bs
        it = ( # it
            f"👤 <b>THÔNG TIN TÀI KHOẢN</b>\n"
            f"• Tên: {escape(str(w['name']))}\n"
            f"• ID Telegram: <code>{i}</code>\n"
            f"• Số dư: <b>{w['balance']:,.0f} VNĐ</b>\n"
            f"• Người được giới thiệu: {w['refs']}\n"
            f"• Thưởng giới thiệu đã nhận: {int(w.get('ref_earnings', 0)):,.0f} VNĐ\n"
            f"• Danh sách ref gần đây: {', '.join(str(x) for x in w.get('referrals', [])[-10:]) or 'Chưa có'}\n"
            f"• Số trận thắng: {w['wins']}\n"
            f"• Cược phiên hiện tại: {bs}"
        )
        await u_obj.message.reply_text(it, parse_mode="HTML")
    elif menu_text_matches(m, "💳 Nạp tiền"):
        kr_nap = InlineKeyboardMarkup([
            [make_inline_button("10 (10.000đ)", callback_data="nap_10"), make_inline_button("50 (50.000đ)", callback_data="nap_50"), make_inline_button("100 (100.000đ)", callback_data="nap_100")],
            [make_inline_button("200 (200.000đ)", callback_data="nap_200"), make_inline_button("500 (500.000đ)", callback_data="nap_500"), make_inline_button("1,000 (1.000.000đ)", callback_data="nap_1000")]
        ])
        await u_obj.message.reply_text("💳 <b>CHỌN MỆNH GIÁ NẠP TIỀN</b>\n• Vui lòng chọn mệnh giá bên dưới để tạo mã QR:", reply_markup=kr_nap, parse_mode="HTML")
    elif menu_text_matches(m, "💸 Rút tiền"):
        await u_obj.message.reply_text("💸 Cú pháp rút tiền:\n<code>/rut [ngân_hàng] [stk] [tên_tk] [số_tiền]</code>", parse_mode="HTML")
    elif menu_text_matches(m, "🔗 Mời bạn"):
        await u_obj.message.reply_text(
            f"🔗 <b>CHƯƠNG TRÌNH GIỚI THIỆU</b>\n"
            f"Mời bạn bằng liên kết bên dưới. Bạn nhận <b>1% tiền cược hợp lệ</b> của người được giới thiệu sau khi phiên chốt.\n"
            f"Link của bạn: <code>https://t.me/madeinnhatdz_bot?start={i}</code>\n"
            f"👥 Đã giới thiệu: <b>{int(w.get('refs', 0))}</b> người\n"
            f"💰 Tổng thưởng: <b>{int(w.get('ref_earnings', 0)):,.0f}đ</b>", parse_mode="HTML")
    elif menu_text_matches(m, "🏆 Bảng xếp hạng"):
        await u_obj.message.reply_text(bxh.tao_noi_dung_bxh(), parse_mode="HTML")
    elif menu_text_matches(m, "📜 Lịch sử cược cá nhân"):
        await xem_lich_su_user(u_obj, w, str(i))
        return
    elif menu_text_matches(m, "🔕 Tắt/Bật thông báo"):
        str_i = str(i) # si
        if str_i in ds_tat_tb:
            ds_tat_tb.remove(str_i)
            f_w(t_f, ds_tat_tb)
            ghi_log_wallet(i, "NOTIFICATIONS_ENABLED", "User enabled round notifications")
            await u_obj.message.reply_text("🔔 Đã <b>BẬT</b> thông báo phiên!", parse_mode="HTML")
        else:
            ds_tat_tb.append(str_i)
            f_w(t_f, ds_tat_tb)
            ghi_log_wallet(i, "NOTIFICATIONS_DISABLED", "User disabled round notifications")
            await u_obj.message.reply_text("🔕 Đã <b>TẮT</b> thông báo phiên!", parse_mode="HTML")
    elif menu_text_matches(m, "🎟️ Nhập code"):
        await u_obj.message.reply_text("🎟️ Nhắn mã dạng <code>BNDZ_XXXXXXXX</code> để nhận thưởng.", parse_mode="HTML")
    elif menu_text_matches(m, "📖 Hướng dẫn"):
        await gui_huong_dan(u_obj)
    else:
        tu = m.upper() # tu
        if tu.startswith("/CODE ") or check_code(tu):
            ck = tu.replace("/CODE ", "").strip() # ck
            if not check_code(ck):
                await u_obj.message.reply_text("❌ Sai định dạng mã!", parse_mode="HTML")
                return
            await xu_ly_nhap_code(u_obj, ck)
        elif tu.startswith("T") or tu.startswith("X"):
            if not c["bet_active"]:
                await u_obj.message.reply_text("🔴 Đã hết giờ cược phiên này!", parse_mode="HTML")
                return
             
            if w.get("current_bet") is not None:
                await u_obj.message.reply_text("⚠️ Bạn đã đặt cược trong phiên này rồi!", parse_mode="HTML")
                return

            try:
                bt = "TAI" if tu.startswith("T") else "XIU" # bt
                amt = int(tu[1:]) # amt
                if amt < 1000 or amt > 100000:
                    await u_obj.message.reply_text("⚠️ Mức cược từ 1.000đ đến 100.000đ!", parse_mode="HTML")
                    return
                if w["balance"] < amt:
                    await u_obj.message.reply_text("❌ Số dư không đủ để đặt cược!", parse_mode="HTML")
                    return
                 
                w["balance"] -= amt
                w["bets_count"] += 1
                w["current_bet"] = {"type": bt, "amount": amt}
                w["nhan_thong_bao"] = True
                 
                str_i = str(i) # si
                if str_i in ds_tat_tb:
                    ds_tat_tb.remove(str_i)
                    f_w(t_f, ds_tat_tb)

                f_w(p, u)
                ghi_log_wallet(i, "PLACE_BET", f"Placed {amt} VND on {bt}", amount=amt, bet_type=bt, session_id=c.get("session_id", 1))
                ghi_log_game(c.get("session_id", 1), i, bt, amt, "BET_PLACED", balance_after=w["balance"])
                nt = "TÀI 🎲" if bt == "TAI" else "XỈU 🎲" # nt
                await u_obj.message.reply_text(f"✅ Đặt cược thành công <b>{amt:,.0f}đ</b> vào cửa <b>{nt}</b>!", parse_mode="HTML")
            except Exception as exc:
                ghi_log_loi(f"Bet input failed: {type(exc).__name__}: {exc}", user_id=str(i), message=m)
                await u_obj.message.reply_text("❌ Không đọc được mức cược. Ví dụ: T10000 hoặc X50000.")
        else:
            await u_obj.message.reply_text("⚠️ Mình chưa hiểu yêu cầu này. Vui lòng chọn chức năng trên menu hoặc nhập đúng cú pháp. Cần hỗ trợ: https://t.me/koka113")

async def show_transaction_menu(message):
    kb = InlineKeyboardMarkup([
        [make_inline_button("💸 Yêu cầu rút tiền", callback_data="admin_withdraw_queue")],
        [make_inline_button("🎟️ Giftcode chờ duyệt", callback_data="tx_giftcode")],
        [make_inline_button("💳 Hướng dẫn đối soát nạp", callback_data="admin_deposit_queue")]
    ])
    await message.reply_text("🧾 <b>TRUNG TÂM QUẢN LÝ GIAO DỊCH</b>\nChọn loại giao dịch cần xử lý:", reply_markup=kb, parse_mode="HTML")

async def cmd_autocode(update, context):
    aid = update.effective_user.id
    if aid not in c.get("admin_ids", []):
        await update.message.reply_text("Bạn không có quyền sử dụng chức năng này."); return
    args = context.args or []
    if len(args) != 2:
        await update.message.reply_text("Cú pháp: /autocode [số_mã] [tiền_mỗi_mã]"); return
    try:
        count, amount = map(int, args)
    except ValueError:
        await update.message.reply_text("Số lượng và số tiền phải là số nguyên."); return
    if not (1 <= count <= 100) or not (1 <= amount <= 200000):
        await update.message.reply_text("Giới hạn: 1–100 mã, 1–200.000đ/mã."); return
    created = []
    alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    for _ in range(count):
        for attempt in range(20):
            code = "BNDZ_" + "".join(secrets.choice(alphabet) for _ in range(10))
            if code not in g and code not in pending_codes:
                pending_codes[code] = {"creator": aid, "max_uses": 1, "amount": amount}
                created.append(code); break
    save_pending_codes()
    ghi_log_admin(aid, "AUTO_CREATE_CODES", f"Created {len(created)} pending codes at {amount} VND")
    await update.message.reply_text(f"🎟️ Đã tạo <b>{len(created)}</b> mã ngẫu nhiên, mỗi mã {amount:,}đ.\nCác mã đang chờ duyệt trong Quản lý giao dịch.", parse_mode="HTML")

async def cmd_lixi(update, context):
    aid = update.effective_user.id
    if aid not in c.get("admin_ids", []):
        await update.message.reply_text("Bạn không có quyền sử dụng chức năng này."); return
    args = context.args or []
    if len(args) != 2:
        await update.message.reply_text("Cú pháp: /lixi [tổng_ngân_sách] [thời_gian_phút]"); return
    try:
        ev = create_event(int(args[0]), int(args[1]), aid)
    except (ValueError, TypeError) as exc:
        await update.message.reply_text(f"❌ {escape(str(exc))}"); return
    ghi_log_admin(aid, "CREATE_LUCKY_MONEY_EVENT", f"Event {ev['id']} total={ev['total']} duration={ev['duration_minutes']}m")
    text = (f"🧧 <b>SỰ KIỆN LÌ XÌ ĐÃ BẮT ĐẦU!</b>\n"
            f"💰 Tổng quỹ: <b>{ev['total']:,}đ</b>\n⏳ Thời gian: <b>{ev['duration_minutes']} phút</b>\n"
            "Mỗi người nhận một lần, phần thưởng ngẫu nhiên theo ngân sách còn lại. Hãy bấm nút 🎁 Nhận lì xì!")
    sent = 0
    admin_ids = {str(x) for x in c.get("admin_ids", [])}
    for uid, account in list(u.items()):
        if account.get("blocked", False) or str(uid) in admin_ids: continue
        try:
            await send_koka_sticker(context.bot, int(uid), "red_envelope")
            await context.bot.send_message(chat_id=int(uid), text=text, parse_mode="HTML")
            sent += 1
        except Exception as exc:
            ghi_log_loi(f"Lucky event broadcast failed: {exc}", user_id=str(uid))
    await update.message.reply_text(f"🧧 Đã mở sự kiện {ev['id']} và gửi thông báo đến {sent} người chơi.")

async def f_c(u_obj: Update, x_obj: ContextTypes.DEFAULT_TYPE):
    query = u_obj.callback_query
    data = query.data or ""
    actor = query.from_user.id
    is_admin = actor in c.get("admin_ids", [])
    
    if data.startswith("allin_"):
        if is_admin or str(actor) not in u or u[str(actor)].get("blocked", False):
            await query.answer("Bạn không có quyền chơi bằng chức năng này.", show_alert=True); return
        side = data.split("_", 1)[1]
        account = u[str(actor)]
        amount = int(account.get("balance", 0))
        if side not in ("TAI", "XIU") or not c.get("bet_active", False) or amount < 1000 or account.get("current_bet"):
            await query.answer("Không thể ALL IN: phiên khóa, số dư thấp hoặc bạn đã cược.", show_alert=True); return
        account["balance"] = 0
        account["bets_count"] = int(account.get("bets_count", 0)) + 1
        account["current_bet"] = {"type": side, "amount": amount}
        account["nhan_thong_bao"] = True
        f_w(p, u)
        ghi_log_wallet(actor, "ALL_IN_BET", f"ALL IN {amount} VND on {side}", amount=amount, bet_type=side)
        ghi_log_game(c.get("session_id", 1), actor, side, amount, "BET_PLACED_ALL_IN", balance_after=0)
        await query.answer("Đã đặt ALL IN!")
        await query.edit_message_text(f"🔥 ALL IN thành công: <b>{amount:,}đ</b> vào cửa <b>{'TÀI' if side == 'TAI' else 'XỈU'}</b>.", parse_mode="HTML")
        await send_koka_sticker(x_obj.bot, actor, "fire")
        return

    if data == "tx_giftcode":
        if not is_admin:
            await query.answer("Bạn không còn quyền này. Vui lòng liên hệ admin.", show_alert=True); return
        rows = [[make_inline_button(f"✅ Duyệt {code}", callback_data=f"gcapprove_{code}"),
                 make_inline_button(f"❌ Từ chối {code}", callback_data=f"gcreject_{code}")]
                for code in list(pending_codes)[:40]]
        await query.answer()
        await query.message.reply_text("🎟️ <b>GIFTCODE CHỜ DUYỆT</b>", reply_markup=InlineKeyboardMarkup(rows) if rows else None, parse_mode="HTML")
        if not rows:
            await query.message.reply_text("Không có mã chờ duyệt.")
        return

    if data.startswith(("gcapprove_", "gcreject_")):
        if not is_admin:
            await query.answer("Bạn không còn quyền này. Vui lòng liên hệ admin.", show_alert=True); return
        code = data.split("_", 1)[1]
        pending = pending_codes.get(code)
        if not pending:
            await query.answer("Mã không còn trong hàng chờ.", show_alert=True); return
        if data.startswith("gcapprove_"):
            g[code] = {"amount": int(pending["amount"]), "max_uses": int(pending["max_uses"]), "used": []}
            f_w(q, g); action = "APPROVE_CODE"
        else:
            action = "REJECT_CODE"
        pending_codes.pop(code, None); save_pending_codes()
        ghi_log_admin(actor, action, f"{action}: {code}")
        await query.answer("Đã xử lý Giftcode.", show_alert=True)
        await query.edit_message_text(f"{'✅ Đã duyệt' if action == 'APPROVE_CODE' else '❌ Đã từ chối'} <code>{escape(code)}</code>", parse_mode="HTML")
        return

    if data.startswith(("wdapprove_", "wdreject_")):
        if not is_admin:
            await query.answer("Bạn không còn quyền này. Vui lòng liên hệ admin.", show_alert=True); return
        uid = data.split("_", 1)[1]
        if uid not in u or not u[uid].get("pending_withdrawal"):
            await query.answer("Yêu cầu không còn chờ xử lý.", show_alert=True); return
        amount = int(u[uid]["pending_withdrawal"].get("amount", 0))
        if data.startswith("wdapprove_"):
            del u[uid]["pending_withdrawal"]; action = "APPROVE_WITHDRAWAL"
            user_msg = f"✅ Yêu cầu rút {amount:,}đ đã được duyệt."
        else:
            u[uid]["balance"] = int(u[uid].get("balance", 0)) + amount
            del u[uid]["pending_withdrawal"]; action = "REJECT_WITHDRAWAL_REFUND"
            user_msg = f"❌ Yêu cầu rút bị từ chối; {amount:,}đ đã được hoàn lại."
        f_w(p, u)
        ghi_log_admin(actor, action, f"{action} for {uid}, amount={amount}", target_user=uid, amount=amount)
        ghi_log_wallet(uid, action, f"Admin {actor}: {action}", admin_id=str(actor), amount=amount)
        try:
            await send_koka_sticker(x_obj.bot, int(uid), "check" if data.startswith("wdapprove_") else "cross_mark")
            await x_obj.bot.send_message(chat_id=int(uid), text=user_msg)
        except Exception as exc: ghi_log_loi(f"Cannot notify withdrawal decision: {exc}", user_id=uid)
        await query.answer("Đã xử lý yêu cầu rút.", show_alert=True)
        await query.edit_message_text(f"{'✅ Đã duyệt' if data.startswith('wdapprove_') else '❌ Đã từ chối và hoàn tiền'} yêu cầu của <code>{escape(uid)}</code> ({amount:,}đ).", parse_mode="HTML")
        return

    # Thêm nhánh xử lý 2 callback_data đúng như yêu cầu trên ảnh số 3
    if data == "admin_deposit_queue":
        if actor not in c.get("admin_ids", []):
            await query.answer(
                "Bạn không còn hoặc không có quyền này. Vui lòng liên hệ admin: https://t.me/koka113",
                show_alert=True
            )
            return
        await query.answer()
        await query.message.reply_text(
            "💳 <b>QUẢN LÝ NẠP TIỀN</b>\n\n"
            "Bot hiện chỉ tạo QR và ghi lịch sử yêu cầu; chưa có webhook/API ngân hàng "
            "để xác minh tiền vào tự động. Không cộng số dư chỉ dựa trên ảnh QR. "
            "Đối chiếu giao dịch thực nhận trước khi dùng /cong.",
            parse_mode="HTML",
        )
        return

    elif data == "admin_withdraw_queue":
        if not is_admin:
            await query.answer("Bạn không còn quyền này. Vui lòng liên hệ admin.", show_alert=True)
            return
        await query.answer()
        found = 0
        for uid, account in list(u.items()):
            pending = account.get("pending_withdrawal")
            if not pending:
                continue
            found += 1
            amount = int(pending.get("amount", 0))
            detail = (f"💸 <b>YÊU CẦU RÚT TIỀN</b>\n"
                      f"User: <code>{escape(str(uid))}</code>\n"
                      f"Số tiền: <b>{amount:,}đ</b>\n"
                      f"Ngân hàng: {escape(str(pending.get('bank', 'Không rõ')))}\n"
                      f"STK: <code>{escape(str(pending.get('account_number', '')))}</code>\n"
                      f"Chủ TK: {escape(str(pending.get('account_name', '')))}")
            kb = InlineKeyboardMarkup([[make_inline_button("✅ Duyệt", callback_data=f"wdapprove_{uid}"),
                                        make_inline_button("❌ Từ chối", callback_data=f"wdreject_{uid}")]])
            await query.message.reply_text(detail, parse_mode="HTML", reply_markup=kb)
        if not found:
            await query.message.reply_text("💸 <b>YÊU CẦU RÚT TIỀN</b>\nKhông có yêu cầu đang chờ.", parse_mode="HTML")
        return

    if data.startswith("nap_"):
        await query.answer()
        try:
            value = int(data.split("_", 1)[1])
            class FakeArgs: args = [str(value * 1000)]
            class FakeUpdate:
                effective_user = query.from_user
                reply_text = query.message.reply_text
                reply_photo = query.message.reply_photo
            await cmd_nap(FakeUpdate(), FakeArgs())
        except Exception as exc:
            ghi_log_loi(f"Deposit callback failed: {type(exc).__name__}: {exc}", user_id=str(actor))
            await query.message.reply_text("❌ Không tạo được QR. Lỗi đã được ghi log.")
        return
    if not is_admin:
        await query.answer("Bạn không còn hoặc không có quyền này. Vui lòng liên hệ admin: https://t.me/koka113", show_alert=True)
        return
    if data.startswith("us_view_"):
        uid = data[len("us_view_"):]
        if uid not in u:
            await query.answer("Không tìm thấy người chơi.", show_alert=True); return
        user = u[uid]
        blocked = bool(user.get("blocked", False))
        action = "us_unblock_" if blocked else "us_block_"
        label = "🔓 Mở chặn người chơi" if blocked else "🚫 Chặn người chơi"
        keyboard = InlineKeyboardMarkup([[make_inline_button(label, callback_data=f"{action}{uid}")]])
        text = (f"👤 <b>Người chơi {escape(uid)}</b>\nTên: {escape(str(user.get('name','(không tên)')))}\n"
                f"Số dư: {int(user.get('balance',0)):,}đ\nThắng: {int(user.get('wins',0))}\n"
                f"Trạng thái: {'BỊ CHẶN' if blocked else 'Đang hoạt động'}")
        await query.answer()
        await query.edit_message_text(text, reply_markup=keyboard, parse_mode="HTML")
        return
    if data.startswith("us_block_") or data.startswith("us_unblock_"):
        block = data.startswith("us_block_")
        uid = data[len("us_block_"):] if block else data[len("us_unblock_"):]
        if uid not in u:
            await query.answer("Không tìm thấy người chơi.", show_alert=True); return
        u[uid]["blocked"] = block
        f_w(p, u)
        action = "BLOCK_USER" if block else "UNBLOCK_USER"
        ghi_log_admin(actor, action, f"{'Blocked' if block else 'Unblocked'} user {uid}", target_user=uid)
        ghi_log_wallet(uid, action, f"Admin {actor} {'blocked' if block else 'unblocked'} this user", admin_id=str(actor))
        await query.answer("Đã chặn người chơi." if block else "Đã mở chặn người chơi.", show_alert=True)
        label = "🔓 Mở chặn người chơi" if block else "🚫 Chặn người chơi"
        next_action = "us_unblock_" if block else "us_block_"
        keyboard = InlineKeyboardMarkup([[make_inline_button(label, callback_data=f"{next_action}{uid}")]])
        await query.edit_message_reply_markup(reply_markup=keyboard)
        return
    await query.answer("Thao tác không hợp lệ.", show_alert=True)

async def e_h(u_obj, c_obj):
    error = c_obj.error
    trace = "".join(traceback.format_exception(type(error), error, error.__traceback__))
    try:
        with open("system_error.txt", "a", encoding="utf-8") as f:
            f.write(f"--- SYSTEM ERROR ---\n{trace}\n")
    except OSError:
        logging.exception("Could not write system_error.txt")
    ghi_log_loi(f"{type(error).__name__}: {error}", traceback=trace[-3500:])
    logging.error("Unhandled Telegram handler exception", exc_info=(type(error), error, error.__traceback__))

async def greeting_scheduler(app_obj):
    """Send daily greetings at 06:00 and 08:00 Vietnam time."""
    tz = ZoneInfo("Asia/Ho_Chi_Minh")
    targets = ((6, 0), (8, 0))
    while True:
        now = datetime.now(tz)
        candidates = []
        for hour, minute in targets:
            candidate = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
            if candidate <= now:
                from datetime import timedelta
                candidate += timedelta(days=1)
            candidates.append(candidate)
        next_run = min(candidates)
        await asyncio.sleep(max(1, (next_run - now).total_seconds()))

        sent_key = next_run.strftime("%Y-%m-%d:%H:%M")
        sent = c.setdefault("morning_greetings_sent", [])
        if sent_key in sent:
            continue
        for uid, account in list(u.items()):
            if account.get("blocked", False):
                continue
            try:
                name = escape(str(account.get("name") or "bạn"))
                balance = int(account.get("balance", 0))
                greeting = (
                    f"☀️ Chào buổi sáng, <b>{name}</b>!\n"
                    f"Chúc bạn một ngày tốt lành.\n"
                    f"💰 Số dư hiện tại: <b>{balance:,} VNĐ</b>"
                )
                await app_obj.bot.send_message(
                    chat_id=int(uid), text=greeting, parse_mode="HTML"
                )
            except Exception as exc:
                ghi_log_loi(
                    f"Morning greeting failed: {type(exc).__name__}: {exc}",
                    user_id=str(uid), scheduled_at=sent_key,
                )
        sent.append(sent_key)
        c["morning_greetings_sent"] = sent[-60:]
        f_w("config.json", c)


async def _post_init(app_obj):
    """Start background jobs only after the Telegram application is initialized."""
    app_obj.create_task(chay_vong_quay_game(app_obj), name="game-round-loop")
    app_obj.create_task(greeting_scheduler(app_obj), name="morning-greeting-loop")


def main():
    try:
        from keep_alive import k as start_health_server
        start_health_server()
    except OSError as exc:
        logging.warning("Health endpoint not started: %s", exc)

    tk = c.get("token", "").strip()
    if not tk:
        raise RuntimeError(
            "Thiếu TELEGRAM_BOT_TOKEN. Hãy đặt biến môi trường TELEGRAM_BOT_TOKEN "
            "bằng token bot mới từ BotFather trước khi chạy."
        )

    app = Application.builder().token(tk).post_init(_post_init).build()
    app.add_handler(CommandHandler("start", c_s))
    app.add_handler(CommandHandler("nap", cmd_nap))
    app.add_handler(CommandHandler("cong", cmd_cong))
    app.add_handler(CommandHandler("tru", cmd_tru))
    app.add_handler(CommandHandler("rut", cmd_rut))
    app.add_handler(CommandHandler("crcode", cmd_crcode))
    app.add_handler(CommandHandler("autocode", cmd_autocode))
    app.add_handler(CommandHandler("lixi", cmd_lixi))
    app.add_handler(CommandHandler("taosticker", cmd_sticker_setup))
    app.add_handler(CommandHandler("taoemoji", cmd_sticker_setup))  # alias tương thích: tạo sticker thường, không tạo custom emoji
    app.add_handler(CommandHandler("addadmin", cmd_addadmin))
    app.add_handler(CommandHandler("kickadmin", cmd_kickadmin))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, h_m))
    app.add_handler(CallbackQueryHandler(f_c))
    app.add_error_handler(e_h)

    logging.info("Starting Telegram bot polling")
    app.run_polling(drop_pending_updates=False)


if __name__ == "__main__":
    main()
