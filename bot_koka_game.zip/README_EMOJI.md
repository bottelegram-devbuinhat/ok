# Koka Game — Emoji miễn phí

Bot dùng emoji Unicode tiêu chuẩn trong nội dung và bàn phím Telegram. Không dùng
Telegram Custom Emoji, sticker TGS tự tạo hoặc sticker pack trả phí. Một số emoji
khi được gửi riêng có thể có hiệu ứng động do chính ứng dụng Telegram hỗ trợ;
hiệu ứng này phụ thuộc emoji, thiết bị và cài đặt của người nhận.

## Hosting và polling

`Procfile` chạy `python main.py` dưới dạng web process. `keep_alive.py` mở HTTP
health endpoint trên `0.0.0.0:$PORT` (mặc định 8080). Telegram update được nhận
bằng long polling qua `Application.run_polling`, không cần webhook hay domain.
Polling có timeout mạng 30–40 giây, poll interval 1 giây và tự retry vô hạn khi
Telegram/API tạm thời không truy cập được. Chỉ chạy một worker/instance cho mỗi
bot token để tránh nhiều tiến trình polling cùng một token.

## Lệnh tương thích

`/taosticker` và `/taoemoji` vẫn được giữ để tương thích; bot trả lời hướng dẫn
về emoji miễn phí thay vì tạo sticker pack.

## Triển khai

1. Cài thư viện: `pip install -r requirements.txt`.
2. Giữ `config.json`, `data.json`, `giftcodes.json` và các tệp dữ liệu cần thiết.
3. Có thể đặt `TELEGRAM_BOT_TOKEN` trong biến môi trường để ghi đè token trong
   `config.json`. Nếu không đặt biến này, token cấu hình hiện tại vẫn được giữ.
4. Chạy `python main.py`.
