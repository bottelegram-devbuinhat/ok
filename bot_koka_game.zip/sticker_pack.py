"""Koka Game animated Telegram stickers (regular TGS stickers; no Premium needed).

The bot can send a TGS file directly at any time. /taosticker optionally creates
an addable regular sticker set for the admin using Telegram Bot API.
"""
from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any


from config import c

BASE_DIR = Path(__file__).resolve().parent
STICKER_DIR = BASE_DIR / "sticker_pack"
MANIFEST_PATH = STICKER_DIR / "manifest.json"


def load_manifest() -> dict[str, Any]:
    try:
        value = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
        if not isinstance(value, dict) or not isinstance(value.get("stickers"), list):
            raise ValueError("Sticker manifest không đúng cấu trúc")
        return value
    except (OSError, ValueError, TypeError):
        return {"title": "Koka Game • Sticker Động", "short_prefix": "koka_game_stickers", "stickers": []}


async def send_koka_sticker(bot, chat_id: int | str, key: str) -> bool:
    """Send a free Unicode emoji instead of uploading a separate sticker.

    Telegram clients may animate supported standalone emoji locally; no Premium
    pack, custom-emoji entitlement, or sticker upload is required.
    """
    manifest = load_manifest()
    entry = next((item for item in manifest.get("stickers", []) if item.get("key") == key), None)
    if not entry:
        logging.warning("Unknown emoji key: %s", key)
        return False
    emoji = str(entry.get("emoji") or "✨")
    try:
        await bot.send_message(chat_id=chat_id, text=emoji)
        return True
    except Exception as exc:
        logging.warning("Free emoji send failed (%s): %s", key, type(exc).__name__)
        return False


async def cmd_sticker_setup(update, context):
    """Explain that the bot uses free built-in emoji, not a paid sticker pack."""
    user = update.effective_user
    message = update.effective_message
    admins = {int(value) for value in c.get("admin_ids", [])}
    if not user or user.id not in admins:
        if message:
            await message.reply_text("⛔ Bạn không có quyền thực hiện lệnh này.")
        return
    if message:
        await message.reply_text(
            "✨ Bot đã chuyển sang emoji Unicode miễn phí. "
            "Không cần Telegram Premium, không tải sticker pack và không dùng Custom Emoji. "
            "Một số emoji độc lập có thể được Telegram tự tạo hiệu ứng động tùy thiết bị/cài đặt."
        )
