HUONG DAN CAI DAT VA VAN HANH
=============================

1. Cai Python 3.10 tro len.
2. Cai thu vien:
   pip install -r requirements.txt
3. Neu CairoSVG khong cai duoc tren Linux/Termux, cai them thu vien he thong Cairo theo huong dan cua he dieu hanh.
4. Dat token bot bang bien moi truong TELEGRAM_BOT_TOKEN (khuyen nghi):
   - Linux/Termux: export TELEGRAM_BOT_TOKEN="TOKEN_MOI"
   - Windows CMD: set TELEGRAM_BOT_TOKEN=TOKEN_MOI
   Khong chia se token trong nhom chat; neu token cu da lo, tao token moi qua BotFather.
5. Chay bot: python main.py
6. Theo doi log: system_error.txt, game_error.log, audit_fallback.log va Firebase RTDB.

CHUC NANG
---------
- Nguoi choi: T[x] / X[x], nut ALL IN, nap/rut, nhap Giftcode, nhan li xi.
- Admin: quan ly nguoi choi, giao dich, Giftcode, tao li xi, soan thong bao, dieu chinh so du.
- Tao Giftcode ngau nhien: /autocode [so_ma] [tien_moi_ma].
- Tao su kien li xi: /lixi [tong_ngan_sach] [thoi_gian_phut].
- Tao Giftcode tuy chon: /crcode [ma] [so_luot] [so_tien]. Tat ca ma moi can duyet trong Trung tam quan ly giao dich.
- Quan ly giao dich: bam nut Duyet/Tu choi cho tung yeu cau rut; duyet/từ chối Giftcode trong cung man hinh.
- Soan thong bao: bam nut, gui tin nhan tiep theo; gui HUY de huy.

LUU Y QUAN TRONG
----------------
- Bot chua ket noi webhook/API ngan hang. QR khong xac nhan tien da vao; admin phai doi soat giao dich that truoc khi cong tien.
- Duyet rut la ghi nhan admin da thanh toan chuyen khoan ben ngoai; bot khong tu chuyen tien.
- ALL IN dat toan bo so du kha dung vao mot cua, khong the hoan lai sau khi dat.
- Moi nguoi chi nhan li xi mot lan trong mot su kien. Phan thuong ngau nhien, toi da khong vuot ngan sach con lai.
- Nen kiem tra Firebase Realtime Database Rules va dung token moi/biến moi truong truoc khi dua len hosting.
- Moi truong hien tai da kiem thu offline; chua the xac minh Telegram/Firebase/VietQR/ngan hang that do thieu ket noi mang va thu vien Telegram.


=== CAI DAT STICKER DONG (KHONG CAN PREMIUM) ===
1. Giu nguyen thu muc sticker_pack/ khi deploy; cai pip install -r requirements.txt.
2. Khoi dong bot. Bot tu gui sticker TGS trong loi chao, ALL IN, li xi va ket qua thang/thua.
3. Admin co the nhan /taosticker trong chat rieng voi bot de tao bo sticker thuong va nhan link t.me/addstickers.
4. Bot luu Telegram file_id tai sticker_pack/file_ids.json; giu file nay khi restart/deploy de tai su dung file_id.
5. Day la sticker dong thuong, khong phai emoji Unicode miễn phí; khong can Telegram Premium. Sticker hien thanh mot tin nhan rieng, khong chay truc tiep trong cau chu hay tren nut bam.
