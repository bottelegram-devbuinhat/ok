"""Offline checks for free Unicode emoji behavior."""
import asyncio
import sticker_pack


def test_manifest_has_unique_free_unicode_emoji():
    manifest = sticker_pack.load_manifest()
    assert manifest["stickers"]
    keys = [item["key"] for item in manifest["stickers"]]
    assert len(keys) == len(set(keys))
    assert all(item.get("emoji") for item in manifest["stickers"])


def test_send_uses_unicode_message_not_paid_sticker():
    class FakeBot:
        def __init__(self):
            self.calls = []

        async def send_message(self, **kwargs):
            self.calls.append(kwargs)

        async def send_sticker(self, **kwargs):
            raise AssertionError("Bot must not upload or send stickers")

    bot = FakeBot()
    assert asyncio.run(sticker_pack.send_koka_sticker(bot, 12345, "dice"))
    assert bot.calls == [{"chat_id": 12345, "text": "🎲"}]


def test_unknown_emoji_key_fails_softly():
    class FakeBot:
        async def send_message(self, **kwargs):
            raise AssertionError("Should not send for unknown key")

    assert asyncio.run(sticker_pack.send_koka_sticker(FakeBot(), 12345, "missing")) is False
